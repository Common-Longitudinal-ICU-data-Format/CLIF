# Vocabulary Index

One row per bundled vocab file. Find your variable, read ONLY that file.
Files marked 'NOT a mapping target' are lookup aids or code lists.

| CLIF table | Vocab file | Rows | Category column | Examples column | Notes |
|---|---|---|---|---|---|
| adt | vocab/adt/clif_adt_hospital_type.csv | 3 | hospital_type_category | hospital_type_name_examples |  |
| adt | vocab/adt/clif_adt_location_categories.csv | 12 | location_category | location_name_examples |  |
| adt | vocab/adt/clif_adt_location_type.csv | 10 | location_type | location_name_examples |  |
| airway | vocab/airway/clif_airway_categories.csv | 4 | airway_category | airway_name_examples |  |
| clinical_notes_facts | vocab/clinical_notes_facts/clif_clinical_notes_facts_note_type_categories.csv | 13 | note_type_category | note_type_examples |  |
| code_status | vocab/code_status/clif_code_status_categories.csv | 15 | code_status_category | code_status_name_examples |  |
| consult_orders | vocab/consult_orders/clif_consult_orders_categories.csv | 15 | order_category | order_name_examples |  |
| consult_orders | vocab/consult_orders/clif_consult_orders_order_status_categories.csv | 4 | order_status_category | (none) | no examples column — match on category + description, be conservative |
| drain | vocab/drain/clif_drain_categories.csv | 10 | drain_category | drain_name_examples |  |
| ed_encounter | vocab/ed_encounter/clif_ed_encounter_arrival_mode_categories.csv | 9 | arrival_mode_category | arrival_mode_name_examples |  |
| ed_encounter | vocab/ed_encounter/clif_ed_encounter_ed_destination_categories.csv | 18 | ed_destination_category | ed_destination_name_examples |  |
| ed_encounter | vocab/ed_encounter/clif_ed_encounter_ed_disposition_categories.csv | 8 | ed_disposition_category | ed_disposition_name_examples |  |
| ed_encounter | vocab/ed_encounter/clif_ed_encounter_triage_acuity_categories.csv | 7 | triage_acuity_category | triage_acuity_name_examples |  |
| ed_encounter | vocab/ed_encounter/clif_ed_encounter_triage_system_categories.csv | 5 | triage_system_category | triage_system_name_examples |  |
| hospitalization | vocab/hospitalization/clif_hospitalization_admission_type_categories.csv | 6 | admission_type_category | admission_type_name_examples |  |
| hospitalization | vocab/hospitalization/clif_hospitalization_discharge_categories.csv | 17 | discharge_category | discharge_name_examples |  |
| input | vocab/input/clif_input_category.csv | 16 | input_category | Examples_notes |  |
| input | vocab/input/clif_input_group.csv | 7 | input_group | Examples | NOT a mapping target (group lookup aid) |
| invasive_hemodynamics | vocab/invasive_hemodynamics/clif_invasive_hemodynamics_measure_categories.csv | 26 | measurement_category | (none) | non-standard layout: 'Maps from' column holds source names; no examples column — match on category + description, be conservative |
| labs | vocab/labs/clif_lab_categories.csv | 113 | lab_category | lab_name_type_examples | lab_category NOT unique — disambiguate with reference_unit + lab_specimen_category (see disambiguation.md); no description column |
| labs | vocab/labs/clif_lab_specimen_categories.csv | 5 | lab_specimen_category | (none) | no examples column — match on category + description, be conservative |
| labs | vocab/labs/clif_labs_order_categories.csv | 17 | lab_order_category | example labs | examples column is 'example labs' |
| line | vocab/line/clif_line_categories.csv | 8 | line_category | line_name_examples |  |
| line | vocab/line/clif_line_sites.csv | 11 | line_site | line_site_name_examples |  |
| mcs | vocab/mcs/clif_mcs_configuration_category.csv | 18 | configuration_category | (none) | no examples column — match on category + description, be conservative |
| mcs | vocab/mcs/clif_mcs_device_category.csv | 7 | device_category | (none) | no examples column — match on category + description, be conservative |
| mcs | vocab/mcs/clif_mcs_setting_category.csv | 11 | setting_category | (none) | no examples column — match on category + description, be conservative |
| mcs | vocab/mcs/clif_mcs_support_category.csv | 4 | support_category | (none) | no examples column — match on category + description, be conservative |
| medication_admin_continuous | vocab/medication_admin_continuous/clif_medication_admin_continuous_action_categories.csv | 7 | mar_action_category | mar_action_name_examples |  |
| medication_admin_continuous | vocab/medication_admin_continuous/clif_medication_admin_continuous_med_categories.csv | 77 | med_category | med_name_examples | has med_dose_unit + volume_infusion_rate_units — cross-check units (see disambiguation.md) |
| medication_admin_continuous | vocab/medication_admin_continuous/clif_medication_admin_continuous_med_route_categories.csv | 3 | med_route_category | med_route_name_examples |  |
| medication_admin_intermittent | vocab/medication_admin_intermittent/clif_medication_admin_intermittent_action_categories.csv | 5 | mar_action_category | mar_action_name_examples |  |
| medication_admin_intermittent | vocab/medication_admin_intermittent/clif_medication_admin_intermittent_med_categories.csv | 271 | med_category | med_name_examples | LARGE — read med_index.md first; has med_dose_unit — cross-check units (see disambiguation.md) |
| medication_admin_intermittent | vocab/medication_admin_intermittent/clif_medication_admin_intermittent_med_route_categories.csv | 5 | med_route_category | med_route_name_examples |  |
| microbiology_culture | vocab/microbiology_culture/clif_microbiology_culture_fluid_category.csv | 44 | fluid_category | fluid_name_examples |  |
| microbiology_culture | vocab/microbiology_culture/clif_microbiology_culture_method_categories.csv | 3 | method_category | method_name_examples |  |
| microbiology_culture | vocab/microbiology_culture/clif_microbiology_culture_organism_categories.csv | 541 | organism_category | organism_name_examples | LARGE — read organism_index.md first; many descriptions empty |
| microbiology_culture | vocab/microbiology_culture/clif_microbiology_culture_organism_groups.csv | 108 | organism_group | (none) | NOT a mapping target (group lookup aid) |
| microbiology_nonculture | vocab/microbiology_nonculture/clif_microbiology_nonculture_fluid_category.csv | 44 | fluid_category | fluid_name_examples |  |
| microbiology_nonculture | vocab/microbiology_nonculture/clif_microbiology_nonculture_method_category.csv | 2 | method_category | method_name_examples |  |
| microbiology_nonculture | vocab/microbiology_nonculture/clif_microbiology_nonculture_organism_category.csv | 24 | organism_category | micro_order_name_examples |  |
| microbiology_nonculture | vocab/microbiology_nonculture/clif_microbiology_nonculture_organism_groups.csv | 11 | organism_group | (none) | NOT a mapping target (group lookup aid) |
| microbiology_nonculture | vocab/microbiology_nonculture/clif_microbiology_nonculture_result_category.csv | 7 | result_category | result_name_examples |  |
| microbiology_susceptibility | vocab/microbiology_susceptibility/clif_microbiology_susceptibility_antibiotics_category.csv | 167 | antimicrobial_category | antimicrobial_name_examples |  |
| microbiology_susceptibility | vocab/microbiology_susceptibility/clif_microbiology_susceptibility_category.csv | 6 | susceptibility_category | susceptibility_name_examples |  |
| misc_icu_orders | vocab/misc_icu_orders/clif_misc_icu_orders_categories.csv | 6 | order_category | order_name_examples |  |
| misc_icu_orders | vocab/misc_icu_orders/clif_misc_icu_orders_order_status_categories.csv | 4 | order_status_category | (none) | no examples column — match on category + description, be conservative |
| output | vocab/output/clif_output_categories.csv | 38 | output_category | output_category_examples |  |
| output | vocab/output/clif_output_groups.csv | 8 | output_group | output_group_examples |  |
| patient | vocab/patient/clif_patient_ethinicity_categories.csv | 7 | ethnicity_category | ethnicity_name_examples |  |
| patient | vocab/patient/clif_patient_language_categories.csv | 47 | language_category | language_name_examples |  |
| patient | vocab/patient/clif_patient_race_categories.csv | 10 | race_category | race_name_examples |  |
| patient | vocab/patient/clif_patient_sex_categories.csv | 5 | sex_category | sex_name_examples |  |
| patient_assessments | vocab/patient_assessments/clif_patient_assessment_categories.csv | 77 | assessment_category | assessment_name_examples |  |
| patient_attributes | vocab/patient_attributes/clif_patient_attributes_attribute_categories.csv | 15 | attribute_category | attribute_name_examples |  |
| patient_attributes | vocab/patient_attributes/clif_patient_attributes_attribute_groups.csv | 6 | attribute_group | (none) | NOT a mapping target (group lookup aid) |
| patient_attributes | vocab/patient_attributes/clif_patient_attributes_attribute_value_categories.csv | 38 | attribute_value_category | (none) | values keyed by applicable_attribute_categories, no examples; no examples column — match on category + description, be conservative |
| patient_procedures | vocab/patient_procedures/clif_patient_procedure_codes.csv | 15 | procedure_code_format | (none) | NOT a mapping target (procedure code list) |
| position | vocab/position/clif_position_categories.csv | 4 | position_category | position_name_examples |  |
| radiology | vocab/radiology/clif_radiology_iv_contrast_categories.csv | 5 | iv_contrast_category | iv_contrast_name_examples |  |
| radiology | vocab/radiology/clif_radiology_location_categories.csv | 3 | radiology_location_category | radiology_location_name_examples |  |
| radiology | vocab/radiology/clif_radiology_modality_categories.csv | 6 | radiology_modality_category | radiology_modality_name_examples |  |
| radiology | vocab/radiology/clif_radiology_region_categories.csv | 15 | radiology_region_category | radiology_region_name_examples |  |
| renal_replacement_therapy | vocab/renal_replacement_therapy/clif_renal_replacement_therapy_mode_categories.csv | 7 | mode_category | mode_name_examples |  |
| respiratory_support | vocab/respiratory_support/clif_respiratory_support_device_categories.csv | 11 | device_category | device_name_examples |  |
| respiratory_support | vocab/respiratory_support/clif_respiratory_support_mode_categories.csv | 11 | mode_category | mode_name_examples |  |
| transfusion | vocab/transfusion/clif_transfusion_component_categories.csv | 5 | component_category | component_name_examples |  |
| vitals | vocab/vitals/clif_vitals_categories.csv | 11 | vital_category | vital_name_examples |  |
